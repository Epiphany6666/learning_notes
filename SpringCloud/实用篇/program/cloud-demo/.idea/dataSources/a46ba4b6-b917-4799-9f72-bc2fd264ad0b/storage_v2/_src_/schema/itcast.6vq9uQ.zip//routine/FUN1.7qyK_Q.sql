create
    definer = root@localhost function FUN1(N1 int) returns int deterministic
BEGIN
    DECLARE TOTAL INT DEFAULT 0;
    while N1 > 0 do
        SET TOTAL := TOTAL + N1;
        SET N1 := N1 - 1;
        END WHILE;
    RETURN TOTAL;
end;

